(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    const grid = document.getElementById("catalogGrid");
    if (!grid) return;

    const products = window.BROFIT_PRODUCTS;
    const mode = document.body.dataset.catalogMode || "all";
    const category = document.getElementById("categoryFilter");
    const size = document.getElementById("sizeFilter");
    const price = document.getElementById("priceFilter");
    const priceValue = document.getElementById("priceValue");
    const sort = document.getElementById("sortFilter");
    const count = document.getElementById("resultCount");
    const loadMore = document.getElementById("loadMore");
    let visible = 8;

    if (price) {
      price.min = "150";
      price.max = "250";
      price.step = "50";
      price.value = "250";
    }

    const queryCategory = new URLSearchParams(location.search).get("category");
    if (queryCategory && category) category.value = queryCategory;

    function buildCatalogLayout() {
      const toolbar = document.querySelector(".catalog-toolbar");
      const filters = toolbar?.querySelector(".filter-grid");
      const section = grid.closest(".section");
      const container = grid.parentElement;
      const loadMoreWrap = loadMore?.parentElement;
      const sortLabel = sort?.closest("label");
      if (!toolbar || !filters || !section || !container) return;

      const titles = {
        all: ["The complete edit", "Shop all styles"],
        new: ["Freshly added", "Latest arrivals"],
        best: ["Most wanted", "Customer favourites"],
        offers: ["Selected value", "Current offers"]
      };
      const heading = titles[mode] || titles.all;
      const layout = document.createElement("div");
      const sidebar = document.createElement("aside");
      const results = document.createElement("div");
      const resultsHead = document.createElement("div");
      const resultsIntro = document.createElement("div");
      const resultsTools = document.createElement("div");

      layout.className = "catalog-layout";
      sidebar.className = "catalog-sidebar";
      results.className = "catalog-results";
      resultsHead.className = "catalog-results-head";
      resultsIntro.innerHTML = `<p class="eyebrow">${heading[0]}</p><h2>${heading[1]}</h2>`;
      resultsTools.className = "catalog-results-tools";

      const sidebarHead = document.createElement("div");
      sidebarHead.className = "catalog-sidebar-head";
      sidebarHead.innerHTML = '<div><p class="eyebrow">Refine your edit</p><h2>Filters</h2></div><button class="catalog-filter-toggle" type="button" aria-expanded="false" aria-controls="catalogFilters">Show filters</button>';
      filters.id = "catalogFilters";
      filters.querySelector(".result-count")?.remove();
      sortLabel?.remove();
      sidebar.append(sidebarHead, filters);

      if (count) resultsTools.appendChild(count);
      if (sortLabel) resultsTools.appendChild(sortLabel);
      resultsHead.append(resultsIntro, resultsTools);
      results.append(resultsHead, grid);
      if (loadMoreWrap) results.appendChild(loadMoreWrap);
      layout.append(sidebar, results);
      container.appendChild(layout);
      section.classList.add("catalog-section");
      toolbar.remove();

      const toggle = sidebar.querySelector(".catalog-filter-toggle");
      toggle.addEventListener("click", function () {
        const open = sidebar.classList.toggle("is-open");
        this.setAttribute("aria-expanded", String(open));
        this.textContent = open ? "Hide filters" : "Show filters";
      });
    }

    buildCatalogLayout();

    function filtered() {
      let result = products.filter(product => {
        if (mode === "new" && !product.isNew) return false;
        if (mode === "best" && !product.isBestSeller) return false;
        if (mode === "offers" && !product.isOffer) return false;
        if (category && category.value !== "All" && product.category !== category.value && !(category.value === "T-Shirts" && product.category.includes("T-Shirts"))) return false;
        if (size && size.value !== "All" && !product.sizes.includes(size.value)) return false;
        if (price && BroFit.currentPrice(product) > Number(price.value)) return false;
        return true;
      });
      if (sort) {
        if (sort.value === "low") result.sort((a, b) => BroFit.currentPrice(a) - BroFit.currentPrice(b));
        if (sort.value === "high") result.sort((a, b) => BroFit.currentPrice(b) - BroFit.currentPrice(a));
        if (sort.value === "best") result.sort((a, b) => (a.rank || 99) - (b.rank || 99));
        if (sort.value === "latest") result.sort((a, b) => Number(b.isNew) - Number(a.isNew) || b.id - a.id);
      }
      return result;
    }

    function render(reset) {
      if (reset) visible = 8;
      const result = filtered();
      if (count) count.textContent = `${result.length} styles`;
      if (priceValue && price) priceValue.textContent = BroFit.money(price.value);
      grid.innerHTML = result.length ? result.slice(0, visible).map(product => BroFit.productCard(product, mode === "best" ? "ranked" : "")).join("") : '<div class="empty-state"><h2>No styles found</h2><p>Try a different category, size or price.</p></div>';
      if (loadMore) loadMore.hidden = visible >= result.length;
      document.querySelectorAll("[data-reveal-item]").forEach(item => item.classList.add("is-visible"));
    }

    [category, size, sort].filter(Boolean).forEach(control => control.addEventListener("change", () => render(true)));
    if (price) price.addEventListener("input", () => render(true));
    if (loadMore) loadMore.addEventListener("click", () => { visible += 4; render(false); });
    render(true);
  });
})();
