(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    const root = document.getElementById("productDetail");
    if (!root) return;
    const id = new URLSearchParams(location.search).get("id") || 1;
    const product = BroFit.byId(id) || window.BROFIT_PRODUCTS[0];
    let activeImage = 0;

    root.innerHTML = `<div class="grid-x grid-margin-x grid-margin-y product-detail-grid">
      <div class="cell large-7">
        <div class="gallery-main"><img id="mainProductImage" src="${product.images[0]}" alt="${product.name}"><button id="prevImage" type="button" aria-label="Previous image">‹</button><button id="nextImage" type="button" aria-label="Next image">›</button></div>
        <div class="gallery-thumbs">${product.images.map((image, index) => `<button type="button" data-image-index="${index}" class="${index === 0 ? "is-active" : ""}"><img src="${image}" alt="${product.name} view ${index + 1}"></button>`).join("")}</div>
      </div>
      <div class="cell large-5 product-summary">
        <p class="eyebrow">${product.category}</p><h1>${product.name}</h1><p class="product-code">Product code: ${product.productCode}</p>
        <div class="detail-price">${product.offerPrice ? `<span>${BroFit.money(product.offerPrice)}</span><del>${BroFit.money(product.price)}</del>` : `<span>${BroFit.money(product.price)}</span>`}</div>
        <p class="stock ${product.stock ? "in-stock" : ""}">${product.stock ? "In stock" : "Currently unavailable"}</p><p>${product.description}</p>
        <fieldset><legend>Select size</legend><div class="size-selector">${product.sizes.map((item, index) => `<label><input type="radio" name="productSize" value="${item}" ${index === 0 ? "checked" : ""}><span>${item}</span></label>`).join("")}</div><a class="text-link" href="size-guide.html">Open size guide</a></fieldset>
        <div class="quantity-row"><label for="quantity">Quantity</label><div class="quantity-control"><button id="minusQty" type="button" aria-label="Decrease quantity">−</button><input id="quantity" type="number" min="1" max="10" value="1" inputmode="numeric"><button id="plusQty" type="button" aria-label="Increase quantity">+</button></div><strong id="dynamicTotal">${BroFit.money(BroFit.currentPrice(product))}</strong></div>
        <div class="stacked-actions"><a id="productWhatsapp" class="button gold expanded whatsapp-button" target="_blank" rel="noopener">${BroFit.whatsappIcon}<span>Order on WhatsApp</span></a><button class="button hollow expanded" type="button" data-wishlist-id="${product.id}">♡ Add to Wishlist</button></div>
        <div class="trust-row"><span>Quality checked</span><span>Size support</span><span>Easy ordering</span></div>
      </div>
    </div>
    <ul class="tabs product-tabs" data-tabs id="productInfoTabs"><li class="tabs-title is-active"><a href="#descriptionPanel" aria-selected="true">Description</a></li><li class="tabs-title"><a href="#detailsPanel">Details</a></li><li class="tabs-title"><a href="#fabricPanel">Fabric</a></li><li class="tabs-title"><a href="#carePanel">Care</a></li><li class="tabs-title"><a href="#shippingPanel">Shipping</a></li><li class="tabs-title"><a href="#exchangePanel">Exchange</a></li></ul>
    <div class="tabs-content" data-tabs-content="productInfoTabs"><div class="tabs-panel is-active" id="descriptionPanel"><p>${product.description}</p></div><div class="tabs-panel" id="detailsPanel"><p>Designed by BRO FIT with a modern silhouette, reinforced finish and size-inclusive fit.</p></div><div class="tabs-panel" id="fabricPanel"><p>Premium cotton-rich fabric. Exact composition can be updated per product batch.</p></div><div class="tabs-panel" id="carePanel"><p>Gentle cold wash. Wash dark colours separately. Dry in shade. Do not iron directly on prints.</p></div><div class="tabs-panel" id="shippingPanel"><p>${BroFit.config.shippingNote}</p></div><div class="tabs-panel" id="exchangePanel"><p>Eligible exchange period: ${BroFit.config.exchangeWindow}. Please review the exchange policy before ordering.</p></div></div>`;
    new Foundation.Tabs($("#productInfoTabs"));

    const image = document.getElementById("mainProductImage");
    const thumbs = root.querySelectorAll("[data-image-index]");
    function setImage(index) {
      activeImage = (index + product.images.length) % product.images.length;
      image.src = product.images[activeImage];
      thumbs.forEach((thumb, thumbIndex) => thumb.classList.toggle("is-active", thumbIndex === activeImage));
    }
    thumbs.forEach(thumb => thumb.addEventListener("click", () => setImage(Number(thumb.dataset.imageIndex))));
    document.getElementById("prevImage").addEventListener("click", () => setImage(activeImage - 1));
    document.getElementById("nextImage").addEventListener("click", () => setImage(activeImage + 1));

    const quantity = document.getElementById("quantity");
    const whatsapp = document.getElementById("productWhatsapp");
    function updateOrder() {
      const selectedSize = root.querySelector('input[name="productSize"]:checked').value;
      quantity.value = Math.min(10, Math.max(1, Number(quantity.value) || 1));
      document.getElementById("dynamicTotal").textContent = BroFit.money(BroFit.currentPrice(product) * Number(quantity.value));
      whatsapp.href = BroFit.whatsappUrl(product, selectedSize, quantity.value);
    }
    root.querySelectorAll('input[name="productSize"]').forEach(input => input.addEventListener("change", updateOrder));
    quantity.addEventListener("input", updateOrder);
    document.getElementById("minusQty").addEventListener("click", () => { quantity.value = Math.max(1, Number(quantity.value) - 1); updateOrder(); });
    document.getElementById("plusQty").addEventListener("click", () => { quantity.value = Math.min(10, Number(quantity.value) + 1); updateOrder(); });
    updateOrder();

    const related = document.getElementById("relatedProducts");
    if (related) related.innerHTML = window.BROFIT_PRODUCTS.filter(item => item.id !== product.id && item.category === product.category).concat(window.BROFIT_PRODUCTS.filter(item => item.id !== product.id && item.category !== product.category)).slice(0, 4).map(item => BroFit.productCard(item)).join("");
    related?.querySelectorAll("[data-reveal-item]").forEach(item => item.classList.add("is-visible"));
    document.title = `${product.name} | BRO FIT`;
  });
})();
