(function ($) {
  "use strict";

  /* EDITABLE STORE CONFIGURATION */
  window.BROFIT_CONFIG = {
    whatsappNumber: "916379387219",
    phone: "+91 63793 87219",
    instagramUrl: "https://www.instagram.com/brofitstores?stkn=eHZzbWFreG16OGdv",
    instagramHandle: "@brofitstores",
    address: "Store location available on request",
    businessHours: "Contact us for current opening hours",
    shippingNote: "Shipping charges and delivery estimates are confirmed before order acceptance.",
    exchangeWindow: "Contact us to confirm the current exchange period"
  };

  /* Future commerce contract. These features intentionally stay inactive until a secure backend is connected. */
  window.BROFIT_COMMERCE = {
    cart: { items: [], currency: "INR" },
    checkoutEnabled: false,
    customerAccountsEnabled: false,
    orderTrackingEnabled: false
  };

  const config = window.BROFIT_CONFIG;
  const products = window.BROFIT_PRODUCTS || [];
  const page = document.body.dataset.page || "";

  const money = value => `₹${Number(value).toLocaleString("en-IN")}`;
  const currentPrice = product => product.offerPrice || product.price;
  const byId = id => products.find(product => product.id === Number(id));
  const whatsappIcon = '<img class="whatsapp-icon" src="assets/images/icons/whatsapp.svg" alt="" aria-hidden="true">';

  function getWishlist() {
    try { return JSON.parse(localStorage.getItem("brofitWishlist")) || []; }
    catch (error) { return []; }
  }

  function saveWishlist(items) {
    localStorage.setItem("brofitWishlist", JSON.stringify(items));
    updateWishlistCount();
  }

  function toggleWishlist(id) {
    const list = getWishlist();
    const next = list.includes(id) ? list.filter(item => item !== id) : [...list, id];
    saveWishlist(next);
    document.querySelectorAll(`[data-wishlist-id="${id}"]`).forEach(button => {
      button.classList.toggle("is-active", next.includes(id));
      button.setAttribute("aria-pressed", String(next.includes(id)));
      button.innerHTML = next.includes(id) ? "♥" : "♡";
    });
    document.dispatchEvent(new CustomEvent("brofit:wishlist-changed"));
  }

  function updateWishlistCount() {
    document.querySelectorAll("[data-wishlist-count]").forEach(node => {
      node.textContent = getWishlist().length;
    });
  }

  function whatsappUrl(product, size, quantity) {
    const qty = Math.max(1, Number(quantity) || 1);
    const unitPrice = currentPrice(product);
    const selectedSize = size || product.sizes[0];
    const message = [
      "Hello BRO FIT,",
      "",
      "I would like to order:",
      "",
      `Product: ${product.name}`,
      `Product Code: ${product.productCode}`,
      `Size: ${selectedSize}`,
      `Quantity: ${qty}`,
      `Price: ${money(unitPrice)}`,
      `Total: ${money(unitPrice * qty)}`,
      "",
      "Name:",
      "Delivery Address:",
      "",
      "Please confirm availability."
    ].join("\n");
    return `https://wa.me/${config.whatsappNumber}?text=${encodeURIComponent(message)}`;
  }

  function productCard(product, extraClass) {
    const wished = getWishlist().includes(product.id);
    const badges = [
      product.isNew ? '<span class="product-badge">New</span>' : "",
      product.isBestSeller ? '<span class="product-badge dark">Best seller</span>' : "",
      product.isOffer && product.offerPrice ? `<span class="product-badge sale">${Math.round((1 - product.offerPrice / product.price) * 100)}% off</span>` : ""
    ].join("");
    const priceMarkup = product.offerPrice
      ? `<span class="price">${money(product.offerPrice)}</span><del>${money(product.price)}</del>`
      : `<span class="price">${money(product.price)}</span>`;

    return `<article class="product-card ${extraClass || ""}" data-reveal-item>
      <div class="product-media">
        <a href="product.html?id=${product.id}" aria-label="View ${product.name}">
          <img class="primary-image" src="${product.images[0]}" alt="${product.name}" loading="lazy">
          <img class="hover-image" src="${product.images[1] || product.images[0]}" alt="Alternate view of ${product.name}" loading="lazy">
        </a>
      <div class="product-badges">${badges}</div>${extraClass === "ranked" ? `<span class="rank-badge" aria-label="Popularity rank ${product.rank}">#${product.rank}</span>` : ""}
        <button class="wishlist-toggle ${wished ? "is-active" : ""}" type="button" data-wishlist-id="${product.id}" aria-label="Add ${product.name} to wishlist" aria-pressed="${wished}">${wished ? "♥" : "♡"}</button>
      </div>
      <div class="product-copy">
        <p class="product-kicker">${product.category} · ${product.productCode}</p>
        <h3><a href="product.html?id=${product.id}">${product.name}</a></h3>
        <div class="product-price">${priceMarkup}</div>
        <div class="size-list" aria-label="Available sizes">${product.sizes.map(size => `<span>${size}</span>`).join("")}</div>
        <div class="product-actions">
          <button class="button hollow small" type="button" data-quick-view="${product.id}">Quick View</button>
          <a class="button gold small whatsapp-button" href="${whatsappUrl(product, product.sizes[0], 1)}" target="_blank" rel="noopener">${whatsappIcon}<span>WhatsApp</span></a>
        </div>
      </div>
    </article>`;
  }

  function headerMarkup() {
    const nav = [
      ["home", "index.html", "Home"], ["shop", "shop.html", "Shop"],
      ["new-arrivals", "new-arrivals.html", "New Arrivals"], ["collections", "collections.html", "Collections"],
      ["offers", "offers.html", "Offers"], ["about", "about.html", "About"], ["contact", "contact.html", "Contact"]
    ];
    const mobileLinks = nav.map(item => `<li class="${page === item[0] ? "is-active" : ""}"><a href="${item[1]}">${item[2]}</a></li>`).join("");
    const links = `<li class="${page === "home" ? "is-active" : ""}"><a href="index.html">Home</a></li>
      <li class="${page === "shop" ? "is-active" : ""}"><a href="shop.html">Shop</a><ul class="menu"><li><a href="shop.html?category=T-Shirts">T-Shirts</a></li><li><a href="shop.html?category=Oversized%20T-Shirts">Oversized T-Shirts</a></li><li><a href="shop.html?category=Plain%20T-Shirts">Plain T-Shirts</a></li><li><a href="shop.html?category=Printed%20T-Shirts">Printed T-Shirts</a></li><li><a href="shop.html?category=Trousers">Trousers</a></li><li><a href="best-sellers.html">Best Sellers</a></li><li><a href="offers.html">Offers</a></li></ul></li>
      ${nav.slice(2).map(item => `<li class="${page === item[0] ? "is-active" : ""}"><a href="${item[1]}">${item[2]}</a></li>`).join("")}`;
    return `<a class="skip-link" href="#main-content">Skip to content</a>
      <header class="site-header" id="siteHeader">
        <div class="grid-container fluid">
          <div class="header-row">
            <button class="menu-toggle hide-for-large" type="button" data-toggle="mobileMenu" aria-label="Open navigation"><span></span><span></span><span></span></button>
            <a class="brand" href="index.html" aria-label="BRO FIT home"><span>BRO</span><b>FIT</b><small>MEN'S WEAR</small></a>
            <nav class="show-for-large" aria-label="Primary navigation"><ul class="dropdown menu main-menu" data-dropdown-menu>${links}</ul></nav>
            <div class="header-tools">
              <button type="button" data-open="searchModal" aria-label="Search products">⌕</button>
              <a href="wishlist.html" aria-label="Wishlist">♡<span class="tool-count" data-wishlist-count>0</span></a>
              <a class="header-whatsapp show-for-medium" href="https://wa.me/${config.whatsappNumber}" target="_blank" rel="noopener" aria-label="WhatsApp BRO FIT">${whatsappIcon}</a>
            </div>
          </div>
        </div>
      </header>
      <aside class="off-canvas position-left mobile-drawer" id="mobileMenu" data-off-canvas aria-label="Mobile navigation">
        <div class="drawer-head"><a class="brand" href="index.html"><span>BRO</span><b>FIT</b></a><button class="close-button" aria-label="Close navigation" type="button" data-close><span aria-hidden="true">×</span></button></div>
        <ul class="vertical menu">${mobileLinks}<li><a href="best-sellers.html">Best Sellers</a></li><li><a href="size-guide.html">Size Guide</a></li></ul>
        <a class="button gold expanded whatsapp-button" href="https://wa.me/${config.whatsappNumber}" target="_blank" rel="noopener">${whatsappIcon}<span>Chat on WhatsApp</span></a>
      </aside>`;
  }

  function footerMarkup() {
    return `<footer class="site-footer">
      <div class="grid-container">
        <div class="grid-x grid-margin-x grid-margin-y">
          <div class="cell medium-5 large-4"><a class="brand footer-brand" href="index.html"><span>BRO</span><b>FIT</b><small>MEN'S WEAR</small></a><p>Modern menswear built around strong fits, wearable colour and everyday confidence.</p><a class="text-link" href="${config.instagramUrl}" target="_blank" rel="noopener">Instagram ${config.instagramHandle}</a></div>
          <div class="cell small-6 medium-3 large-2"><h2>Shop</h2><a href="shop.html">T-Shirts</a><a href="shop.html?category=Trousers">Trousers</a><a href="new-arrivals.html">New Arrivals</a><a href="best-sellers.html">Best Sellers</a><a href="offers.html">Offers</a></div>
          <div class="cell small-6 medium-4 large-2"><h2>Help</h2><a href="size-guide.html">Size Guide</a><a href="faq.html">FAQ</a><a href="shipping.html">Shipping</a><a href="exchange-policy.html">Exchange Policy</a><a href="bulk-orders.html">Bulk Orders</a></div>
          <div class="cell small-6 medium-4 large-2"><h2>Company</h2><a href="about.html">About</a><a href="contact.html">Contact</a><a href="account.html">My Account Preview</a><a href="order-tracking.html">Order Tracking</a><a href="privacy-policy.html">Privacy</a><a href="terms.html">Terms</a></div>
          <div class="cell small-6 medium-4 large-2"><h2>Contact</h2><a href="tel:${config.phone.replace(/\s/g, "")}">${config.phone}</a><a href="https://wa.me/${config.whatsappNumber}" target="_blank" rel="noopener">WhatsApp</a><p>${config.address}</p></div>
        </div>
        <div class="footer-bottom"><span>© ${new Date().getFullYear()} BRO FIT — Men's Wear. All Rights Reserved.</span><span>Style. Comfort. Confidence.</span></div>
      </div>
    </footer>
    <a class="floating-whatsapp" href="https://wa.me/${config.whatsappNumber}" target="_blank" rel="noopener" aria-label="Chat with BRO FIT on WhatsApp">${whatsappIcon}</a>
    <nav class="mobile-bottom-nav hide-for-medium" aria-label="Quick navigation">
      <a href="index.html"><span>⌂</span>Home</a><a href="shop.html"><span>▦</span>Shop</a><button type="button" data-open="searchModal"><span>⌕</span>Search</button><a href="wishlist.html"><span>♡</span>Wishlist</a><a class="mobile-whatsapp" href="https://wa.me/${config.whatsappNumber}" target="_blank" rel="noopener">${whatsappIcon}<small>Chat</small></a>
    </nav>`;
  }

  function searchMarkup() {
    return `<div class="reveal search-reveal" id="searchModal" data-reveal>
      <button class="close-button" data-close aria-label="Close search" type="button"><span aria-hidden="true">×</span></button>
      <p class="eyebrow">Find your fit</p><h2>Search BRO FIT</h2>
      <label for="globalSearch">Product name, code or category</label>
      <input id="globalSearch" type="search" placeholder="Try BF001 or oversized" autocomplete="off">
      <div id="searchSuggestions" class="search-suggestions" aria-live="polite"></div>
    </div><div class="reveal quick-view-reveal" id="quickViewModal" data-reveal><button class="close-button" data-close aria-label="Close quick view" type="button"><span aria-hidden="true">×</span></button><div id="quickViewContent"></div></div>`;
  }

  function initSearch() {
    const input = document.getElementById("globalSearch");
    const results = document.getElementById("searchSuggestions");
    if (!input || !results) return;
    input.addEventListener("input", function () {
      const query = this.value.trim().toLowerCase();
      if (!query) { results.innerHTML = '<p class="muted">Start typing to see products.</p>'; return; }
      const matches = products.filter(product => `${product.name} ${product.productCode} ${product.category}`.toLowerCase().includes(query)).slice(0, 6);
      results.innerHTML = matches.length ? matches.map(product => `<a href="product.html?id=${product.id}"><img src="${product.images[0]}" alt=""><span><b>${product.name}</b><small>${product.productCode} · ${product.category}</small></span><strong>${money(currentPrice(product))}</strong></a>`).join("") : '<p class="muted">No products found. Try another word.</p>';
    });
    $("#searchModal").on("open.zf.reveal", () => setTimeout(() => input.focus(), 100));
  }

  function initHome() {
    const newGrid = document.getElementById("newArrivalGrid");
    const bestGrid = document.getElementById("bestSellerGrid");
    if (newGrid) newGrid.innerHTML = products.filter(product => product.isNew).slice(0, 4).map(product => productCard(product)).join("");
    if (bestGrid) bestGrid.innerHTML = products.filter(product => product.isBestSeller).slice(0, 4).map(product => productCard(product)).join("");
  }

  function initRevealAnimations() {
    const items = document.querySelectorAll("[data-reveal-item]");
    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      items.forEach(item => item.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add("is-visible"); observer.unobserve(entry.target); }
    }), { threshold: 0.12 });
    items.forEach(item => observer.observe(item));
  }

  function initForms() {
    document.querySelectorAll("[data-newsletter-form]").forEach(form => form.addEventListener("submit", event => {
      event.preventDefault();
      form.innerHTML = '<p class="form-success">Thanks. You are on the BRO FIT update list.</p>';
    }));
    const contactForm = document.getElementById("contactForm");
    if (contactForm) $(contactForm).on("formvalid.zf.abide", event => {
      event.preventDefault();
      document.getElementById("formStatus").textContent = "Thanks. Your message is ready for the BRO FIT team.";
    });
    if (contactForm) $(contactForm).on("submit", event => event.preventDefault());
    const bulkForm = document.getElementById("bulkForm");
    if (bulkForm) bulkForm.addEventListener("submit", event => {
      event.preventDefault();
      const data = new FormData(bulkForm);
      const message = `Hello BRO FIT,\n\nI have a bulk order enquiry.\n\nName: ${data.get("name")}\nMobile: ${data.get("mobile")}\nQuantity: ${data.get("quantity")}\nRequirement: ${data.get("requirement")}\nMessage: ${data.get("message")}\n\nPlease contact me with details.`;
      window.open(`https://wa.me/${config.whatsappNumber}?text=${encodeURIComponent(message)}`, "_blank", "noopener");
    });
  }

  document.addEventListener("click", event => {
    const wishlistButton = event.target.closest("[data-wishlist-id]");
    if (wishlistButton) toggleWishlist(Number(wishlistButton.dataset.wishlistId));
    const quickViewButton = event.target.closest("[data-quick-view]");
    if (quickViewButton) {
      const product = byId(quickViewButton.dataset.quickView);
      const content = document.getElementById("quickViewContent");
      if (product && content) {
        content.innerHTML = `<div class="grid-x grid-margin-x grid-margin-y align-middle"><div class="cell medium-6"><img class="quick-view-image" src="${product.images[0]}" alt="${product.name}"></div><div class="cell medium-6"><p class="eyebrow">${product.category} · ${product.productCode}</p><h2>${product.name}</h2><div class="detail-price"><span>${money(currentPrice(product))}</span>${product.offerPrice ? `<del>${money(product.price)}</del>` : ""}</div><p>${product.description}</p><p class="quick-sizes"><strong>Sizes:</strong> ${product.sizes.join(" · ")}</p><a class="button gold expanded whatsapp-button" href="${whatsappUrl(product, product.sizes[0], 1)}" target="_blank" rel="noopener">${whatsappIcon}<span>Order on WhatsApp</span></a><a class="button hollow expanded" href="product.html?id=${product.id}">View full details</a></div></div>`;
        $("#quickViewModal").foundation("open");
      }
    }
  });

  window.BroFit = { money, currentPrice, byId, productCard, getWishlist, saveWishlist, toggleWishlist, whatsappUrl, whatsappIcon, config };

  $(function () {
    $("#site-header-slot").html(headerMarkup());
    $("#site-footer-slot").html(footerMarkup());
    $("#search-slot").html(searchMarkup());
    if (!document.querySelector('link[rel="icon"]')) {
      const favicon = document.createElement("link");
      favicon.rel = "icon";
      favicon.type = "image/svg+xml";
      favicon.href = "assets/images/icons/favicon.svg";
      document.head.appendChild(favicon);
    }
    $(document).foundation();
    initHome();
    initSearch();
    initForms();
    updateWishlistCount();
    initRevealAnimations();
    document.querySelectorAll("[data-whatsapp-link]").forEach(link => {
      link.href = `https://wa.me/${config.whatsappNumber}`;
      if (!link.querySelector(".whatsapp-icon")) link.insertAdjacentHTML("afterbegin", whatsappIcon);
      link.classList.add("whatsapp-button");
    });
    document.querySelectorAll('a[href*="instagram.com/brofit"]').forEach(link => { link.href = config.instagramUrl; });
    document.querySelectorAll("[data-config-phone]").forEach(node => { node.textContent = config.phone; if (node.tagName === "A") node.href = `tel:${config.phone.replace(/\s/g, "")}`; });
    document.querySelectorAll("[data-config-address]").forEach(node => { node.textContent = config.address; });
    document.querySelectorAll("[data-config-hours]").forEach(node => { node.textContent = `Business hours: ${config.businessHours}`; });
    const contactConfigNote = document.querySelector(".contact-panel code")?.closest("p");
    if (contactConfigNote) contactConfigNote.textContent = "For product, size, order and exchange support, contact us through any channel below.";

    const reviewSlider = document.querySelector(".testimonial-slider");
    if (reviewSlider) {
      document.querySelector("[data-review-prev]")?.addEventListener("click", () => reviewSlider.scrollBy({ left: -reviewSlider.clientWidth * .7, behavior: "smooth" }));
      document.querySelector("[data-review-next]")?.addEventListener("click", () => reviewSlider.scrollBy({ left: reviewSlider.clientWidth * .7, behavior: "smooth" }));
    }

    $(window).on("scroll", function () {
      $("#siteHeader").toggleClass("is-scrolled", window.scrollY > 30);
      const hero = document.querySelector(".hero");
      if (hero && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) hero.style.setProperty("--parallax-y", `${Math.min(window.scrollY * 0.12, 70)}px`);
    });
  });
})(jQuery);
