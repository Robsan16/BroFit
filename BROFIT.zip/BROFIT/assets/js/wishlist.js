(function () {
  "use strict";
  document.addEventListener("DOMContentLoaded", function () {
    const grid = document.getElementById("wishlistGrid");
    if (!grid) return;
    function render() {
      const ids = BroFit.getWishlist();
      const items = ids.map(id => BroFit.byId(id)).filter(Boolean);
      grid.innerHTML = items.length ? items.map(product => BroFit.productCard(product)).join("") : '<div class="empty-state"><p class="eyebrow">Your edit</p><h2>Your wishlist is empty</h2><p>Save the styles you like and come back when you are ready.</p><a class="button gold" href="shop.html">Explore the shop</a></div>';
      document.querySelectorAll("[data-reveal-item]").forEach(item => item.classList.add("is-visible"));
    }
    document.addEventListener("brofit:wishlist-changed", render);
    render();
  });
})();
